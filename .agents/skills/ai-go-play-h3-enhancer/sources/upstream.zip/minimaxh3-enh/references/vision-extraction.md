# Vision Extraction — reading the input images

The prompt's fidelity is decided here, not in the prose. A prompt written from a filename or a vague memory of the picture will contradict the reference frame within its first clause, and the model will spend the whole clip resolving that contradiction instead of animating.

Run this protocol on **every** attached image before drafting anything.

## The observation pass

Produce a short internal note per image. It is scratch work — it never appears in the artifact — but writing it explicitly is what stops the drift.

```
IMG1  role: first frame | last frame | subject donor | set donor | style donor | storyboard
style:      live-action / cinematic / 2D-animated / 3D CG / claymation / watercolour / vintage film
grade:      palette, contrast, saturation, grain, any format tell (halation, anamorphic flare, video noise)
framing:    shot size (extreme close / close / medium close / medium / medium wide / wide / extreme wide)
            camera height and angle (eye level, low, high, overhead, dutch)
            subject placement in frame, headroom, lead room, depth layers
subjects:   per person or animal —
            apparent age band, build, hair (length, colour, texture, how it sits), skin tone,
            wardrobe item by item with colour and material, accessories, distinguishing features,
            pose, weight distribution, hand positions, gaze direction, expression
props:      named objects, their state (open/closed, full/empty, intact/broken), who holds what and how
environment: location type, key set dressing, surfaces, weather, time of day, background depth
light:      key direction and quality, fill, practicals, colour temperature, shadow behaviour
text:       every legible word, transcribed verbatim in its original script
spatial:    who is left/right/foreground/background of whom; what occludes what
LOCKED:     the details that must survive unchanged into the video
affordances: what could plausibly move or change next from this exact state
```

## Turning observation into prompt clauses

**Locked details go in early and stay consistent.** In I2VA, the opening sentence establishes them explicitly — "preserving her appearance, clothing, seat position, and the carriage layout" is doing real work, because it tells the model which axes are not free to drift.

**Compress, don't dump.** The note may hold thirty observations; the prompt needs the load-bearing ten. Prefer the details that (a) identify the subject, (b) will be visibly affected by the action, and (c) would look wrong if the model invented them differently. A silver necklace matters if the shot pushes into her collar; it is noise if the shot is a wide.

**Write appearance, not identity.** Describe what a viewer sees. Never name a real person, never guess who someone is, never infer nationality, health, or private attributes from a face.

**Do not assert the unseen.** You may extend the world plausibly — a street beyond a window, traffic implied by a reflection — but write it as new scene content, not as something "shown in `<Picture 1>`". Anything attributed to the picture must actually be in the picture.

**Style is derived, not chosen.** For any keyframe or donor task, the style declaration comes from the image. If the reference is soft-lit 2D animation, the prompt does not open with "live-action, cinematic". For T2VA only, pick the style from the user's text.

## FL2VA: the delta table

Two frames of the same scene means the description body is the *difference* between them. Build this before writing:

| Axis | Picture 1 | Picture 2 | Path |
| --- | --- | --- | --- |
| Subject pose | | | how it changes |
| Prop state | | | the manipulation that changes it |
| Position in frame | | | the movement |
| Composition / framing | | | the camera motion that produces it |
| Light / weather / time | | | the transition |

Axes with no delta are continuity constraints — state them once as preserved and don't keep re-describing them. Axes with a delta get the verbs. Then order the deltas so the differences narrow toward the end and the final clause lands explicitly on Picture 2.

## L2VA: reverse inference

The image is the destination. Work backwards: what state, one duration earlier, makes this final frame the natural consequence of a continuous action? Choose an earlier state that (a) shares the location, light, and wardrobe of the final frame, (b) differs on exactly the axes the action will change, and (c) is reachable in the available seconds. Then write forward — earlier state, transition, convergence, landing.

Note also which elements of the final frame are already present at the start (they anchor continuity) and which only come into existence through the action (they need the verbs). In the specification's worked example, the hand and sleeve exist from the first frame; the broken glass does not.

## Multiple images in full-reference mode

Decide, per image, what it actually contributes, then label accordingly:

- Contributes a **person, animal, object, environment, costume, effect, style, action or pose** that appears in the target video → it becomes a `<Subject N>`, and the image is cited *inside* that subject's definition rather than getting its own `<Picture N>` line.
- Serves as a **concrete frame or composition anchor** (first frame, keyframe, last frame, storyboard) → it gets a standalone `<Picture N>` entry.

One subject may draw on several images; one image may supply several subjects. Say which asset provides what when it isn't obvious: *"whose appearance comes from `<Picture 1>` and whose walking motion comes from `<Video 1>`"*.
