# Output Formats — the five mode skeletons

Reproduce these character-for-character. The instruction lines are fixed strings; the em dash, the angle brackets, the square brackets, and the two-decimal duration are all part of the format. Where the source specification is inconsistent between modes (I2VA and L2VA bracket `<Picture 1>`, FL2VA does not), follow each mode's own template rather than normalising across them.

`S.SS` = effective video duration, always two decimals (`6.00`, `8.00`, `10.00`).
`N` = index of the actual final shot. In single-shot FL2VA and L2VA that is `1`.

---

## T2VA — text only

No instruction line. Begin directly with the three core fields.

```text
integrated_multimodal_description: [Shot 1] <style>, <opening composition and subjects>. <action, camera, dialogue, diegetic sound along the timeline> [Shot 2] At MM:SS.mmm, the camera cuts to <new information>...

overall_soundscape: <1–4 sentences of ambience, physical action sound, non-verbal human sound>

non_diegetic_music: <1–3 sentences of instrumentation, tempo, rhythm, dynamics — or N/A>
```

---

## I2VA — one image, the literal first frame

```text
For the target video, at 0.00 seconds into the target video, <Picture 1> (from [Shot 1]) is fully referenced.

integrated_multimodal_description: [Shot 1] <style>, <the subject shown in <Picture 1>> remains <position/state>, preserving <appearance, clothing, position, layout>. <camera motion> as <action onset>. <continuous development, dialogue, result or reaction>

overall_soundscape: ...

non_diegetic_music: ...
```

The picture is the video at 0.00 seconds and belongs to `[Shot 1]`. Establish style, subjects, composition and scene anchors from the image first, then move.

---

## FL2VA — two images, first and last frame

```text
How the reference pictures align with the target video — Picture 1 (from Shot 1) aligns with the 0.00-second mark of the target video; Picture 2 (from Shot N) aligns with the S.SS-second mark of the target video.

integrated_multimodal_description: [Shot 1] <style>, <subject> begins in the position and framing established by Picture 1, <first-frame state>. <camera motion> as <intermediate change 1>, <intermediate change 2>, <narrowing difference>, and settles into the pose, spacing, and composition established by Picture 2 at the end of the shot.

overall_soundscape: ...

non_diegetic_music: ...
```

Prefer a single shot; with one shot, `Shot N` is `Shot 1`. The body is the motion path, not two still descriptions.

---

## L2VA — one image, the literal last frame

```text
How the reference pictures align with the target video — <Picture 1> (from [Shot N]) aligns with the S.SS-second mark of the target video.

integrated_multimodal_description: [Shot 1] <style>, <a plausible earlier state compatible with the final image>. <camera motion> as <explicit action and transition path>. Toward the end, <gradual convergence> settle into the exact <arrangement, position, camera angle, lighting, and final composition> established by <Picture 1>.

overall_soundscape: ...

non_diegetic_music: ...
```

`<Picture 1>` belongs to the final shot, not Shot 1 — unless the video is a single shot, in which case they coincide.

---

## Full-reference mode — donors, multiple assets, reference video or audio

Six sections, in this order, each section name on its own line followed by its content. Note the two differences from base modes: the main field is renamed, and the style declaration moves *above* `[Shot 1]`.

```text
subject_definitions:
<Subject 1> is <what it denotes, its reference role, its features to follow>, from <Picture 1>.
<Subject 2> is ...
<Audio 1> is ...

summary:
[task type + task type] <one short paragraph using the defined labels — no new labels introduced here>

retention_analysis:
<Subject 1> (appears in [Shot 1], [Shot 2]): fully_preserved - <what is retained>
<Picture 2> ([Shot 1] first frame): fully_preserved - <what is retained>
<Audio 1>: reference - <what is referenced without copying>

detailed_description:
<one or two English sentences establishing overall style, lighting and palette>
[Shot 1] <composition, subjects with labels at first appearance, environment, light, action, camera, sound, dialogue>
[Shot 2] At MM:SS.mmm, the shot cuts to <...>

overall_soundscape:
<ambience and physical sound across the full video>

non_diegetic_music:
<audience-only score — or N/A>
```

Each shot goes on its own line in full-reference mode (unlike base modes, where shots run inline in one paragraph).

---

## Field semantics, shared by all modes

| Field | Contains |
| --- | --- |
| `integrated_multimodal_description` / `detailed_description` | Visuals, actions, shot changes, camera, speakers, dialogue, singing, and diegetic audio, in playback order |
| `overall_soundscape` | Ambience, physical action sound, non-verbal human sound across the whole video — no dialogue, no singing, no diegetic music |
| `non_diegetic_music` | Background score only the audience can hear — instrumentation, tempo, rhythm, dynamics |

`N/A` in `overall_soundscape` only when the user explicitly asks for total silence. `N/A` in `non_diegetic_music` whenever there is no audience-only score.
