# Worked Examples

Three complete runs, thin IDEA to finished prompt. Read these when calibrating how dense and how specific to write. Note in each case how little the user gave and how much of the enhancement comes from decisions the skill made deliberately rather than details the user supplied.

---

## Example 1 — T2VA

**IDEA:** "guy misses his bus in the rain"
**No assets.** Duration defaulted to 6.00s. Two shots: the miss, then the reaction — the cut earns its place by changing subject scale and information.

```text
integrated_multimodal_description: [Shot 1] Live-action, cinematic, a medium-wide shot frames a young man in a soaked grey hoodie running along a wet pavement toward a bus stop as the bus pulls away from the kerb ahead of him. The camera trucks left with large amplitude at fast speed, keeping pace with him until he slows, stops beside the empty shelter, and lowers his outstretched arm. [Shot 2] At 00:03.800, the camera cuts to a low-angle close shot of his face as he tips his head back into the rain, breathing hard, and the young man with a hoarse, winded voice (S1) says: <d>[English] Of course.</d> He wipes the water from his eyes with the back of his wrist and pushes both hands into his front pocket.

overall_soundscape: Heavy rain drums on the shelter roof and splashes underfoot while tyres hiss through standing water. The bus engine fades into the distance, leaving fast footsteps that slow to a stop and heavy, uneven breathing.

non_diegetic_music: A single sustained synth tone at a slow tempo, joined by a soft kick pulse that drops out on the final breath.
```

---

## Example 2 — I2VA

**IDEA:** "she blows out the candle"
**One image**, described by the user as the opening frame.

Vision note (internal, never shipped):

```
IMG1  role: first frame
style:      live-action, cinematic, warm low-key interior, soft grain
framing:    medium close, eye level, subject frame-centre behind table
subject:    girl, roughly 8–10, dark hair in two plaits, mustard knitted cardigan
                over a white collar, both forearms resting on the table edge
props:      small round chocolate cake, one lit candle centre, two blue paper
                plates, one folded paper crown beside the cake
environment: kitchen table, dark room behind, window frame-left with pale evening light
light:      candle as key from below, cool window fill from the left, deep shadow behind
text:       none
LOCKED:     plaits, mustard cardigan, single candle, two blue plates, paper crown,
                table position, window left, low-key warm grade
affordances: lean in, cup hand by flame, breath, flame out, smoke, light shifts cool
```

Prompt:

```text
For the target video, at 0.00 seconds into the target video, <Picture 1> (from [Shot 1]) is fully referenced.

integrated_multimodal_description: [Shot 1] Live-action, cinematic, warm low-key interior, the girl shown in <Picture 1> stays seated at the kitchen table behind the small round chocolate cake, preserving her dark plaited hair, mustard knitted cardigan, the single lit candle, the two blue paper plates, the folded paper crown, and the dark room and window behind her. The camera pushes in with small amplitude at slow speed as she leans forward over the table, cups one hand beside the flame, and draws a short breath. The flame stretches sideways, flickers twice, and goes out; a thin line of smoke rises through the frame, and the warm light on her face falls away to the pale window light from the left. She sits back into her chair and smiles with her lips closed while the smoke thins.

overall_soundscape: Quiet room tone with a low refrigerator hum continues underneath. A chair creaks as she leans forward, a short breath crosses the candle, and a faint rustle of knitted fabric follows in the silence afterward.

non_diegetic_music: N/A
```

Note what the enhancement did: it named the locked details explicitly in the first sentence so they cannot drift, gave the candle a three-stage physical behaviour instead of "she blows it out", and handled the lighting change as an observable consequence rather than a mood. `non_diegetic_music` is `N/A` because the IDEA implies an intimate real-time moment and no score was requested.

---

## Example 3 — Full-reference

**IDEA:** "my dog in my parents' living room, someone off-screen calls his name and he bolts toward the camera — use my voice from the clip"
**Assets:** a photo of the dog, a photo of the living room, a voice memo. Three assets and no literal frame anchor, so this routes to full-reference. Duration 8.00s, two shots.

```text
subject_definitions:
<Subject 1> is the tan-and-white corgi in <Picture 1>, with a broad white chest blaze, upright pointed ears, a dark muzzle, short legs, and a red webbing collar with a round brass tag.
<Subject 2> is the living-room environment in <Picture 2>, with a green velvet sofa, a low oak coffee table, a cream rug with a worn edge, bare floorboards beyond the rug, and tall net curtains over a bay window.
<Audio 1> is the voice-timbre reference for the off-screen speaker (S1), containing a spoken English vocal layer with a warm mid-range female voice and an unhurried delivery.

summary:
[reference generation + audio reference] The target video shows <Subject 1> lying on the rug in <Subject 2> until an off-screen voice calls his name, after which he rises and runs toward the camera. The two-shot sequence uses <Audio 1> as the voice-timbre reference for the off-screen speaker (S1) and ends with the dog stopping close to the lens.

retention_analysis:
<Subject 1> (appears in [Shot 1], [Shot 2]): fully_preserved - the tan-and-white coat, white chest blaze, upright pointed ears, dark muzzle, and red collar with a round brass tag are retained.
<Subject 2> (appears in [Shot 1], [Shot 2]): fully_preserved - the green velvet sofa, low oak coffee table, cream rug, bare floorboards, and net-curtained bay window are retained.
<Audio 1>: reference - its warm mid-range timbre and unhurried delivery guide the off-screen line without copying the original signal.

detailed_description:
The target video is live-action and cinematic, lit by soft daylight through net curtains, with a warm and slightly desaturated palette and shallow depth of field.
[Shot 1] A low medium-wide shot establishes <Subject 2>, the living room with its green velvet sofa, low oak coffee table, cream rug with a worn edge, and tall net curtains over the bay window, with bare floorboards running toward the camera. <Subject 1>, the tan-and-white corgi with a broad white chest blaze, upright pointed ears, a dark muzzle, and a red webbing collar with a round brass tag, lies on the rug at the centre of the frame with his chin flat across his front paws and his eyes half closed. The camera holds a static shot while diffused daylight shifts slowly across the rug and dust moves in the window light behind him. An off-screen woman with a warm mid-range voice and an unhurried delivery (S1), following the timbre referenced from <Audio 1>, calls from beyond the left edge of the frame: <d>[English] Biscuit, come here.</d> <Subject 1> lifts his head, his ears swivel forward, his weight shifts onto his front legs, and he pushes upright with his back end still low.
[Shot 2] At 00:03.500, the camera cuts to a low close shot at rug height as <Subject 1> breaks into a run directly toward the lens, his shoulders rolling and his ears flattening back with the speed. The camera pulls out with small amplitude at fast speed, holding his head and chest in frame while the green velvet sofa and low oak coffee table of <Subject 2> slide past on either side and the cream rug gives way to bare floorboards beneath him. His brass tag swings and taps against his chest, his tongue is visible at the side of his mouth, and his front paws land close to the lens before he stops hard, drops his shoulders and forelegs into a low bow, and looks up just off-axis from the camera with his tail moving quickly behind him.

overall_soundscape:
Quiet indoor room tone with faint traffic beyond the window continues throughout. Claws scrabble against the rug and then tap rapidly across bare floorboards, accompanied by fast panting, the light rattle of a metal tag, and a short scuff as he stops.

non_diegetic_music:
N/A
```

Note the routing decision: neither photo is a first or last frame, so neither gets a standalone `<Picture N>` entry — both are cited inside the `<Subject N>` definitions they define. The voice memo is `reference`, not `fully_copy`, because only the timbre carries across while the words come from the user's IDEA.

---

## The artifact these become

Every run ships as one markdown file. Example 2 rendered as the deliverable:

````markdown
# minimaxH3 — Candle

**Mode:** I2VA · **Duration:** 6.00s · **Shots:** 1 · **Images:** 1

## Prompt

```text
For the target video, at 0.00 seconds into the target video, <Picture 1> (from [Shot 1]) is fully referenced.

integrated_multimodal_description: [Shot 1] Live-action, cinematic, warm low-key interior, ...

overall_soundscape: ...

non_diegetic_music: N/A
```

## Image slots

- `Picture 1` → first frame → `birthday-table.jpg`

## Notes

- Locked from the reference: plaits, mustard cardigan, single candle, two blue plates, paper crown, table position, window left.
- Single shot at 6.00s — a cut would cost the continuous flame behaviour, which is the shot's whole event.
- No score, on the assumption this should play as a real-time moment. Say the word and I'll add a sparse piano bed.
````
