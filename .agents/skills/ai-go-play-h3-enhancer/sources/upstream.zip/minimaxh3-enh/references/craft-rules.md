# Craft Rules — shots, camera, speech, text, audio

Shared by every mode. These are the conventions the model was trained to read; deviating from them costs control, not style points.

## 1. Shots and cuts

`[Shot 1]` never carries a timestamp. Every later shot opens with a strictly increasing cut time inside the duration:

```text
[Shot 2] At 00:03.500, the camera cuts to...
```

Format is `MM:SS.mmm` — zero-padded minutes and seconds, three decimal places.

Ordinary cut verbs: `the camera cuts to`, `the shot cuts to`, `the shot transitions to`, `the shot changes to`, `the shot switches to`. Cross-dissolve, fade and wipe only when the user asks for them.

**A cut must introduce new information** — a new subject, space, state, viewpoint, or time. If all that changes is distance or a slight angle, use camera motion instead; a cut spent on a framing change reads as an editing error.

Shot budget by duration: 6s → 1–2 shots; 8s → 1–3; 10s → 2–4. Each shot needs roughly 1.5 seconds minimum to register. FL2VA prefers a single shot so the model can interpolate continuously between the two frames.

## 2. Camera motion — type, amplitude, speed

Use only these motion types. Amplitude and speed are optional and should be added only when meaningful; medium amplitude and normal speed are simply omitted.

| Dimension | Expression | Meaning |
| --- | --- | --- |
| Motion type | `Zoom In` / `Zoom Out` | Focal length changes, body stationary |
| Motion type | `Push In` / `Pull Out` | Camera moves forward / backward |
| Motion type | `Pan Left` / `Pan Right` | Lens pivots horizontally in place |
| Motion type | `Truck Left` / `Truck Right` | Camera translates horizontally |
| Motion type | `Tilt Up` / `Tilt Down` | Lens pivots vertically in place |
| Motion type | `Pedestal Up` / `Pedestal Down` | Whole camera rises / lowers |
| Motion type | `Arc Shot` | Camera arcs around the subject |
| Motion type | `Tracking Shot` | Camera follows a moving subject |
| Motion type | `Static Shot` | Position and lens both still |
| Motion type | `Shake Slightly` / `Shake Strongly` | Slight / strong shake |
| Motion type | `POV` | Subject's point of view |
| Motion type | `Roll Clockwise` / `Roll Counterclockwise` | Roll around the lens axis |
| Amplitude | `with small amplitude` / `with large amplitude` | Range of compositional change |
| Speed | `at slow speed` / `at fast speed` | Pacing of that change |

Write the move as natural English action inside the sentence, not as labels bolted onto the end:

```text
The camera pushes in with small amplitude at slow speed toward the folded letter in her hands.
The camera pans right with large amplitude at fast speed, revealing the open doorway.
The camera holds a static shot as the runner exits the frame.
```

## 3. Speakers and dialogue

Anyone who speaks, sings, or produces an off-screen human voice gets a stable ID: `(S1)`, `(S2)`, assigned in order of first actual vocal event and never renumbered. Characters who never vocalise get no ID. Simultaneous speech by already-numbered speakers uses a compound ID: `(S1,S2)`.

On first appearance, give enough context to fix a stable vocal identity — character type, age, gender, on- or off-screen, pitch, timbre, rate, accent.

**Everything except the language tag and the words themselves stays outside `<d>`.** Identity, delivery, and accompanying action go before or after the tag.

```text
The young woman with a quiet, breathy voice (S1) says: <d>[English] I get off at the next station.</d>
The two children (S1,S2) shout together, <d>[English] Wait for us!</d>
```

**Preserve the user's words exactly** — every word, every punctuation mark, in the original language. Do not translate, rewrite, tidy, or re-punctuate. Where source speech is genuinely unintelligible, write `[unclear]` rather than guessing.

**Voiceover** uses the exact phrase `says in an off-screen voiceover`, and every voiceover `<d>` block is immediately followed by a statement that the on-screen character's lips remain closed — otherwise the model will animate a mouth:

```text
The man (S1) says in an off-screen voiceover: <d>[English] I still remember that road.</d> while his lips remain completely closed.
```

**Speech crossing a cut** takes `<scenetrans>` at the connecting point in both parts, plus an explicit continuity statement: `continues seamlessly across the cut`, `continues uninterrupted into the next shot`, `carries over from the previous shot`, or `remains audible across the transition`.

**Speech truncated by the end of the video** takes `<cutoff>`.

## 4. On-screen text

Any banner, sign, label, subtitle, or neon text actually visible in frame goes in English double quotation marks, verbatim, in its original script, untranslated:

```text
A red neon sign reading "营业中" glows above the doorway.
```

## 5. `overall_soundscape`

One paragraph, 1–4 English sentences, covering the whole video: ambience, physical action sound, non-verbal human sound. Wind, rain, traffic, footsteps, fabric, impacts, breathing, laughter, panting.

Dialogue, singing, and diegetic music already live in the description body and must not be repeated here. Use `N/A` only when the user explicitly asks for complete silence throughout.

```text
overall_soundscape: Steady rain taps against the café windows while low room ambience continues underneath. The entrance bell rings once, followed by wet footsteps and the soft scrape of a chair.
```

## 6. `non_diegetic_music`

1–3 English sentences describing score only the audience hears. Give instrumentation, tempo, rhythm, and dynamic change. Do **not** use abstract mood words and do **not** explain what the music is emotionally doing — the model renders sound, not intent.

Anything a character could hear — a busker, a car radio, a phone speaker, a television, someone singing — is a diegetic event and belongs in the description body instead. Use `N/A` when there is no audience-only score.

```text
non_diegetic_music: Sparse piano notes at a slow tempo, joined by sustained low strings that gradually increase in volume before fading out.
```

## 7. Density

Base modes typically run 110–220 words in the description field for a 6–10 second clip, scaling with shot count and dialogue load. Full-reference `detailed_description` normally runs 350–500 words.

Dialogue-dense content prioritises fitting the complete spoken timeline over hitting a word count. A single shot does not automatically justify a short description — a single shot with continuous camera movement and a state change needs the same specificity as three cuts. Never pad with restatement or adjectives; add words only where they add a visible or audible fact.

## 8. The test every clause must pass

*Could a camera record this, or a microphone capture it?*

Fails: "a sense of quiet longing", "conveying her isolation", "the music underscores the tension", "she is conflicted".
Passes: "she stops mid-step", "her hand tightens on the strap", "sustained low strings increase in volume", "she looks toward the door and back down".
