# Full-Reference Mode

Read this only when routing to full-reference mode: three or more assets, any reference video or audio, any image acting as a donor rather than a literal frame, or a mix of frame anchors and donors.

Everything in `craft-rules.md` still applies — shots, camera, speaker IDs, `<d>`, visible text, the two audio fields. What changes is that the prompt now has to *declare* what it is borrowing, from where, and how faithfully.

Write all six sections in English. Preserve original language only for dialogue and lyrics inside `<d>` and for text visibly present in the scene.

## The four label types

| Label | Denotes |
| --- | --- |
| `<Subject N>` | Visible content abstracted from the assets, reused or modified in the target video |
| `<Picture N>` | A reference image acting as a concrete target frame or shot-planning anchor |
| `<Video N>` | A reference video providing an editing source, continuation point, or whole-video temporal structure |
| `<Audio N>` | An audio signal that is copied or referenced |

A label, once assigned, keeps the same meaning across all six sections. `<Video N>` and `<Audio N>` are numbered independently — index does not encode pairing, and the same source file can be both `<Video 1>` and `<Audio 2>`.

## 1. `subject_definitions`

One line per item that must be tracked separately later. Each line says what the label denotes, what role it plays, and the main features to follow. Name the source asset when provenance needs to be explicit.

```text
<Subject 1> is the young woman in <Picture 1>, with long dark hair, a blue cardigan, and a thin silver necklace.
<Subject 1> is the woman whose appearance comes from <Picture 1> and whose walking motion comes from <Video 1>.
<Picture 2> is the first frame of [Shot 1], showing a woman seated beside a café window.
<Picture 3> is a storyboard reference for [Shot 1] and [Shot 2], defining their viewpoint, subject placement, and shot order.
<Video 1> is the source video for the target video edit.
<Audio 1> is the voice-timbre reference for <Subject 1> (S1).
```

Decision rules:

- An image used **only** to define a character, scene, costume, or style gets **no** standalone `<Picture N>` line — cite it inside the relevant `<Subject N>` definition instead.
- A person, object, scene, action or effect lifted out of a reference video is still a `<Subject N>`. `<Video N>` names the asset or its structure; it does not replace subject labels.
- An ordinary reference video does not generate an `<Audio N>` merely because the file has sound. Create `<Audio N>` only when audio is actually copied or referenced.
- When an `<Audio N>` maps to a target speaker, reuse that speaker's global ID — `<Subject N> (Sx)`, or a stable voice description plus `(Sx)`. The ID comes from the target video's vocal-event order; the audio definition never assigns a new one.
- One audio asset serving several roles gets one natural sentence, not extra subsections.

## 2. `summary`

One short paragraph, opening with a square-bracketed task-type prefix, using only labels already defined.

| Task type | Use when |
| --- | --- |
| `keyframe completion` | An image serves as a first frame, keyframe, last frame, edited keyframe, or other concrete frame anchor |
| `reference generation` | An asset guides a character, scene, style, action, camera move or storyboard without being a concrete frame or an edited/continued source |
| `video editing` | An existing source video is directly modified |
| `video continuation` | New content continues, extends, resumes or transitions from a source video |
| `audio reuse` | The same audio signal is reused in whole or in part |
| `audio reference` | Only style, timbre, content, texture, beat or continuity is referenced, not copied |

Combine with ` + `, never repeating a type: `[video continuation + keyframe completion]`, `[video editing + audio reuse]`.

The presence of a video or an audio file does not by itself create a task type. A reference video supplying only camera movement, cuts or rhythm is `reference generation`. Use `video editing` or `video continuation` only when that video is genuinely edited or continued. When editing a source video whose original audio stays audible, add `audio reuse`; when continuing a source video without copying the signal, add `audio reference`.

For editing tasks, begin the summary body with: `The target video is an edited version of <Video 1>.`

## 3. `retention_analysis`

One line per label, recording where it appears and how faithfully it survives. Choose the marker **within the role already defined** for that label — newly added actions, backgrounds or plot events in the target video are not fidelity losses.

Visible content — `<Subject N>`, `<Picture N>`, `<Video N>`:

| Marker | Meaning |
| --- | --- |
| `fully_preserved` | The defined role is fully preserved |
| `partially_preserved` | Still used, but some defined characteristics change or are only partly retained |
| `attribute_transfer` | Referenced characteristics move to a different identifiable target subject |
| `weak_reference` | Only broad similarity of style, category, composition or atmosphere remains |

Audio — `<Audio N>`:

| Marker | Meaning |
| --- | --- |
| `fully_copy` | The complete source audio is the target's complete final audio track |
| `partially_copy` | Part of the timeline or selected layers are copied, or sounds are added, removed or replaced after copying |
| `reference` | Not copied; only timbre, rhythm, style, dialogue content or texture is referenced |
| `weak_reference` | Only broad similarity of category or atmosphere remains |

```text
<Subject 1> (appears in [Shot 1], [Shot 3]): fully_preserved - the exposed brick wall, orange tufted sofa, and neon sign are retained.
<Picture 2> ([Shot 1] first frame): fully_preserved - the seated pose, window light, and table layout are retained.
<Video 1> (cut and pacing structure): weak_reference - only the three-beat cut rhythm is followed.
<Audio 1>: reference - the target speaker follows its voice timbre and measured delivery without copying the original signal.
```

Never write `(Sx)` in this section.

## 4. `detailed_description`

The main body. Same shot, camera, speaker and dialogue formats as base modes, with three differences:

- The field is named `detailed_description`, not `integrated_multimodal_description`.
- The style declaration is one or two sentences **before** `[Shot 1]`, not inside it.
- Reference labels are inserted at each label's first clear appearance and wherever its role applies.

```text
The target video is in a cinematic, literary music-video style with soft lighting and a slightly desaturated colour palette.
[Shot 1] The scene opens in a crowded urban street...
[Shot 2] At 00:09.000, the shot cuts to an extreme close-up...
```

At an important `<Subject N>`'s first clear appearance, describe its referenced characteristics, its position in frame, and its current action — within what is actually visible in that shot. Afterwards, keep using the label without redefining it.

Natural phrasing for concrete frame anchors: `the shot begins from <Picture 1>`, `the shot's keyframe corresponds to <Picture 2>`, `the shot ends on <Picture 3>`. Cite `<Video N>` where its source state, structure or continuation relationship applies, and `<Audio N>` in the shot or phase where the audio relationship is active.

Make this section **explicit, not summarising**. For each shot establish composition, subject appearance and position, environment and lighting, actions and state changes, camera movement, current sound, and the points where referenced content actually takes effect. A plot summary or a list of reference relationships is a failed `detailed_description`.

Length: normally 350–500 English words for generation tasks. Dialogue-dense content prioritises the complete spoken timeline over word count. Editing descriptions scale with the source video's complexity. Distribute detail across shots by information load, not evenly.

## 5. Speakers with reference labels

When a referenced subject physically speaks, keep both labels:

```text
<Subject 2> (S1) turns toward the woman and says, <d>[English] Last summer, I went to my grandfather's house. He talked about you.</d>
```

`<Subject N>` identifies the referenced subject; `(Sx)` identifies the speaker. Off-screen delivery keeps the same form, marked `off-screen`. A speaker with no corresponding subject gets a stable voice description plus `(Sx)`.

When verbal content exists **only as a cue inside a reused BGM or complete soundtrack**, with no person, character or narrator physically producing it, cite `<Audio N>` as the audible source and do not invent an `(Sx)`:

```text
When <Audio 1> reaches the phrase <d>[English] I'm lonely lonely lonely lonely lonely I'm lonely</d>, <Subject 1> performs the corresponding hand gesture without becoming a separate speaker source.
```

When dialogue, narration or lyrics from reference audio are directly reused — or the user asks for them to be reperformed — preserve the exact source words and original language inside `<d>`, writing `[unclear]` for unintelligible spans. Standardise punctuation to basic written marks (`,` `.` `?` `!`), removing tildes, emoji, bullets and decorative repetition, and end complete statements, questions and exclamations with `.`, `?` or `!` before `</d>`. When only timbre, rhythm, emotion or delivery is referenced, do **not** carry the original dialogue across.

## 6. The two audio sections

Same definitions as base modes. When reference audio is used, state its copy or reference relationship only in the section matching the audible layer — ambience and effects in `overall_soundscape`, audience-only score in `non_diegetic_music`. If one asset supplies both, describe the relevant relationship in each:

```text
overall_soundscape: The copied ambience layer from <Audio 1> continues throughout the target video.
non_diegetic_music: <Audio 2> is directly reused as the complete audience-only score.
```

Complete dialogue and lyrics appear only inside `<d>` in `detailed_description` — never repeated in these two sections.
