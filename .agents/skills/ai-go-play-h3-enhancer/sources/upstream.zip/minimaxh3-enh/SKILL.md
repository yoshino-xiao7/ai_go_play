---
name: minimaxh3-enh
description: Enhance a rough user IDEA into a paste-ready MiniMax Hailuo 3 (minimaxH3) video prompt — routing automatically between T2VA, I2VA, FL2VA, L2VA and full-reference mode, reading every attached image with vision first, and emitting the exact fields the model expects (integrated_multimodal_description or detailed_description, overall_soundscape, non_diegetic_music, plus subject_definitions, summary and retention_analysis). Use whenever a user wants a video prompt enhanced, expanded, rewritten or built for MiniMax, Hailuo, Hailuo 3, H3 or minimaxH3, or gives a short video idea plus reference images and wants a finished prompt back. Trigger on "minimaxH3-ENH", "minimaxh3", "enhance this video prompt", "image to video prompt", "first and last frame prompt", "T2VA", "I2VA", "FL2VA", "L2VA", "integrated_multimodal_description", "subject_definitions", "animate this image". Always use when the deliverable is a minimaxH3 prompt, even if the user only says "write me a video prompt" and attaches a picture.
---

# minimaxH3-ENH — MiniMax Hailuo 3 Prompt Enhancer

Turn a rough IDEA — one line, a paragraph, a beat sheet, a screenplay fragment, or a bare image with "make this move" — into a **single paste-ready minimaxH3 prompt** written to the model's exact expected format.

The skill's whole value is that the model rewards *specificity that is grounded in what will actually be on screen*. A vague prompt produces a vague video; a prompt that invents details contradicting the attached image produces a video that drifts off its own first frame. So the two things this skill does that a naive rewrite does not:

1. **It looks at the images before it writes.** Every attached image is read with vision and reduced to a locked-detail inventory (identity, wardrobe, props, palette, lighting, spatial layout, visible text). Those locked details then reappear, unchanged, in the prompt body.
2. **It routes to the correct mode and writes that mode's exact skeleton.** The five modes are not stylistic variants — they have different first lines, different field names, and different jobs for the description body. Getting the mode wrong wastes the reference images entirely.

## What you produce

One markdown artifact, semantically named `[slug]-minimaxH3-prompt.md`, containing:

- the complete prompt in a single fenced block, ready to copy whole
- an image-slot map (which attached file is `Picture 1`, `Picture 2`, `<Subject 2>`, etc.)
- brief generation notes (mode, duration, shot count, and any judgement calls made)

Write the file into the working directory (or the user's stated output path), then present it. Keep the chat reply to two or three lines. If the user explicitly asks for the prompt inline instead of a file, print the fenced block and skip the artifact.

This skill **generates prompts only**. It never generates the video.

## Reference files

Read these as needed. Do not try to work from memory — the format strings are load-bearing and must be reproduced character-for-character.

| File | Read it when |
| --- | --- |
| `references/output-formats.md` | Always. The exact skeleton for all five modes, verbatim instruction lines, field order, spacing. |
| `references/vision-extraction.md` | Whenever any image is attached. The observation protocol and how observations become prompt clauses. |
| `references/craft-rules.md` | Always. Camera vocabulary enum, shot/timing rules, speaker and dialogue syntax, on-screen text, soundscape and music rules, word budgets. |
| `references/full-reference-mode.md` | Only when routing to full-reference mode. Labels, task-type prefixes, retention markers, six-section structure. |
| `references/examples.md` | When unsure how dense or how specific to write. Three worked IDEA → prompt examples. |

## Workflow

### Step 1 — Read the IDEA and inventory the inputs

Extract from the user's text, without inventing yet:

- **Intent** — what happens, to whom, where. One sentence.
- **Dialogue or lyrics** — any quoted speech. Copy it out verbatim, character for character, including its original language and punctuation. This is the single most commonly corrupted element; never translate it, never tidy it, never paraphrase it.
- **Duration** — if stated, use it. If not, default to `6.00` seconds. (10.00 is the other common Hailuo length; use it if the IDEA clearly needs more beats than 6 seconds allows.)
- **Explicit constraints** — "single shot", "no music", "silent", "vertical", a named cut time, a requested camera move, a specified style.
- **Assets** — count the attached images. Note any reference video or audio.

If the IDEA already contains a formatted prompt from a previous run, treat it as a draft to improve rather than source material to describe.

### Step 2 — Look at every image (mandatory when images exist)

Do not skip this and do not guess from filenames. Open each image and run the observation protocol in `references/vision-extraction.md`, producing an internal note per image covering: style and grade, shot size and camera height, each subject's appearance and wardrobe, props and their state, environment and light, any visible text transcribed verbatim, spatial relationships, and the **locked list** — the details that must survive into the video unchanged.

Two rules that matter more than the rest:

- **Never contradict the image.** If the coat is olive, it stays olive in every sentence. Contradiction is how a prompt fights its own reference frame.
- **Never assert what isn't visible.** You may add plausible off-frame detail (a street beyond the window, a sound the scene implies), but do not describe an unseen face, an unseen object state, or a background you cannot see as though it were in the picture. And when a real person appears in an image, describe their appearance — never name them or guess who they are.

For two-image FL2VA, also build the **delta table**: what differs between Picture 1 and Picture 2 in pose, prop state, position, composition, and lighting. Those deltas *are* the description body.

### Step 3 — Route to a mode

| Situation | Mode |
| --- | --- |
| No images, no reference video or audio | **T2VA** |
| One image that is literally the video's opening frame ("start here", "animate this photo") | **I2VA** |
| Two images that are literally the opening and closing frames | **FL2VA** |
| One image that is literally the video's closing frame ("end on this", "this is the final shot") | **L2VA** |
| Any image used as an identity / wardrobe / set / style **donor** rather than a literal frame | **full-reference** |
| Three or more images, or any reference video, or any reference audio, or a mix of frame anchors and donors | **full-reference** |

The disambiguation that trips people up: *one image, one mode?* No. A single portrait plus "make a video of her walking through a market" is **full-reference** — the photo is a subject donor, not a first frame, because the video does not begin in that pose in that room. The same portrait plus "she looks up from this and smiles" is **I2VA**. Read the IDEA's verbs: *start from / animate / from this frame* → frame anchor; *a video of this person / in this style / wearing this* → donor.

Likewise two images are only FL2VA when they are the same continuous scene at two points in time. A person photo plus a location photo is full-reference.

### Step 4 — Lock the timeline before writing prose

Decide, and write down, in this order:

1. **Duration** `S.SS`, always two decimals.
2. **Shot count.** 6s → 1–2 shots. 8s → 1–3. 10s → 2–4. FL2VA strongly prefers a single shot so the model can interpolate cleanly; use multiple shots only if the user asked. A cut must earn its place by introducing new information — new subject, space, state, viewpoint, or time. If only the framing distance needs to change, use camera motion instead of a cut.
3. **Cut times.** `[Shot 1]` never carries a timestamp. Every later shot opens with `At MM:SS.mmm,` strictly increasing, inside the duration, and leaving each shot at least ~1.5s of screen time so it reads.
4. **Dialogue budget.** Conversational English runs ≈2.5–3 words per second; Mandarin ≈4–5 characters per second. A 6-second clip comfortably holds ~12–15 English words *total* once you leave room for action and breath. If the user's dialogue exceeds the budget, either extend the duration or plan a `<cutoff>`; never speed-read it and never silently trim their words.
5. **Speaker roster.** Assign `(S1)`, `(S2)` … in order of first actual vocal event. Silent characters get no ID. IDs never change or renumber across shots.

### Step 5 — Ask only when a decision is genuinely load-bearing

Default to inferring and proceeding — a good prompt now beats a questionnaire. Use `ask_user_input_v0` only when a choice materially changes the output and cannot be inferred, most often:

- **Mode ambiguity** that the IDEA's verbs don't settle (frame anchor vs subject donor) — this one is worth asking, because guessing wrong wastes the images.
- **Duration** when the IDEA's action plainly won't fit 6 seconds.
- **Dialogue language** when the user's quoted line could plausibly be delivered in more than one language.

One question, two to four options, then proceed. Never ask about things you can simply choose well (camera moves, ambience, music instrumentation).

### Step 6 — Write the prompt

Open `references/output-formats.md` and copy the skeleton for the routed mode exactly — the instruction line, the blank line after it, the field names, the field order. Then fill the body using `references/craft-rules.md` for camera, dialogue, text, and audio syntax, and `references/full-reference-mode.md` if applicable.

The body's job differs by mode, and this is where enhancement actually happens:

- **T2VA** — build the whole audiovisual timeline from text. You have licence to add scene, character, action, and sound detail, as long as it stays consistent with the user's intent.
- **I2VA** — first-frame anchor → action onset → continuous development → result or reaction. Establish the image's style, subjects, composition and scene anchors first, *then* move.
- **FL2VA** — first-frame state → observable intermediate changes → progressively narrowing differences → last-frame state. Do not write two static image descriptions with a gap in the middle; write the motion path that connects them, and land the final shot explicitly on Picture 2's pose, spacing and composition.
- **L2VA** — plausible preceding state → explicit action and transition path → gradual convergence → last-frame landing. Infer an earlier state compatible with the final image, then converge on it.
- **Full-reference** — six sections, style sentence *before* `[Shot 1]`, reference labels inserted at first appearance and wherever their role applies.

Throughout: every clause must correspond to something a viewer could **see or hear**. "A sense of quiet longing" is unusable; "she stops mid-step and her hand tightens on the strap" is usable. Emotional interpretation, authorial intent, and explanations of what the music is *for* all belong outside the prompt.

### Step 7 — Validate before you write the file

Run this checklist against the drafted prompt. Every item here corresponds to a real failure the format produces when violated.

**Structure**
- [ ] Instruction line reproduced verbatim for I2VA / FL2VA / L2VA; absent for T2VA; correct six sections for full-reference
- [ ] Exactly one blank line between the instruction line and the first field
- [ ] Field names spelled exactly (`integrated_multimodal_description` in base modes, `detailed_description` in full-reference) and in the right order
- [ ] `S.SS` duration formatted to two decimals, and it matches the duration used in the body

**Timeline**
- [ ] `[Shot 1]` has no timestamp; every later shot has one
- [ ] Cut times strictly increasing, all inside the duration, none crowding the end
- [ ] Style declared once — after `[Shot 1]` in base modes, before `[Shot 1]` in full-reference

**Reference fidelity**
- [ ] Every locked detail from the vision pass appears, unaltered — no colour, garment, prop, or layout drift
- [ ] Nothing asserted that isn't visible in the image or plausibly implied
- [ ] FL2VA lands the final shot explicitly on Picture 2; L2VA lands explicitly on Picture 1
- [ ] Full-reference: every label defined in `subject_definitions` is used in the body, and no label is used that wasn't defined

**Speech and text**
- [ ] Dialogue inside `<d>[Language] ...</d>` is byte-identical to the user's, untranslated
- [ ] Only the language tag and spoken words sit inside `<d>`; speaker identity, delivery and action sit outside
- [ ] Speaker IDs assigned in vocal-event order, consistent across shots, none given to silent characters
- [ ] Every voiceover uses the exact phrase `says in an off-screen voiceover` and is immediately followed by a statement that the on-screen lips remain closed
- [ ] Visible on-screen text is inside English double quotes and preserved verbatim in its original script

**Audio**
- [ ] `overall_soundscape` is 1–4 sentences, one paragraph, ambience and physical and non-verbal human sound only — no dialogue, no singing, no diegetic music repeated from the body
- [ ] `non_diegetic_music` is 1–3 sentences of instrumentation, tempo, rhythm and dynamics — no mood words, no explanation of emotional function
- [ ] Anything the characters can hear (radio, busker, phone speaker, TV) lives in the description body, not in `non_diegetic_music`
- [ ] `N/A` used only where genuinely warranted

**Camera**
- [ ] Only vocabulary from the motion-type table; amplitude and speed added only when meaningful
- [ ] Camera motion written as natural English action inside the sentence, not stacked as labels at the end

### Step 8 — Write and present the artifact

Use this structure:

````markdown
# minimaxH3 — [Short Title]

**Mode:** I2VA · **Duration:** 6.00s · **Shots:** 1 · **Images:** 1

## Prompt

```text
[the complete prompt, exactly as it should be pasted]
```

## Image slots

- `Picture 1` → first frame → `river-window.png`

## Notes

- [judgement calls, alternatives, anything the user may want to adjust]
````

Then present the file and stop. No long postamble.

## Failure modes worth naming

These are the mistakes that survive a careless pass and quietly ruin the generation:

- **Describing the reference image twice instead of describing motion.** Especially in FL2VA. The model already has both frames; what it lacks is the path between them.
- **Prose that narrates feeling rather than events.** Every sentence should survive the question "what would a camera record here?"
- **Silent contradiction.** A prompt that says "her red scarf" over an image of a grey scarf sets the model fighting itself for the whole clip.
- **Cut inflation.** Three cuts in six seconds gives each shot two seconds; nothing lands. Prefer one well-moved shot.
- **Dialogue drift.** Translating, re-punctuating, or "cleaning up" the user's line. Their words are data, not draft copy.
- **Diegetic/non-diegetic confusion.** A busker the character walks past is in the body. An audience-only score is in `non_diegetic_music`. Putting the busker in the music field makes the model mix it as score.
- **Labels in the wrong mode.** `<Subject N>`, `retention_analysis`, and `summary` belong to full-reference mode only. Base modes have three fields and no subject labels.
