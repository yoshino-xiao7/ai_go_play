# minimaxH3-ENH

A Claude Skill that turns a rough one-line IDEA into a complete, spec-compliant **MiniMax Hailuo 3** video prompt. You give it what you want to see — plus any reference images — and it gives back a single paste-ready prompt written in the exact field structure the model expects, with every reference image actually read before a word is written. It exists because Hailuo 3's prompt format is unusually strict: five different task modes with different opening lines, different field names, and different jobs for the description body, plus fixed vocabularies for camera motion, speaker IDs, dialogue tags, and the diegetic/non-diegetic audio split. Getting any of that wrong doesn't produce a slightly worse video — it produces a video that ignores your reference frames or animates a mouth that should be closed.

## What it does

Two things a naive prompt rewrite doesn't.

**It looks at the images before it writes.** Every attached image is read with vision and reduced to a locked-detail inventory — identity, wardrobe, props, palette, lighting, spatial layout, visible text transcribed verbatim. Those locked details then reappear unchanged in the prompt body. A prompt that says "her red scarf" over an image of a grey scarf sets the model fighting its own reference frame for the entire clip; this is the step that prevents that.

**It routes to the correct mode.** The five modes are not stylistic variants. `T2VA` builds a timeline from text alone. `I2VA`, `FL2VA`, and `L2VA` treat images as literal first, first-and-last, or final frames. Full-reference mode treats assets as *donors* — a character, a set, a voice timbre — and declares each one with `<Subject N>` / `<Picture N>` / `<Video N>` / `<Audio N>` labels, a task-type prefix, and a retention analysis. The distinction that trips people up: one portrait plus *"animate this photo"* is I2VA, but the same portrait plus *"a video of her walking through a market"* is full-reference, because the video never begins in that pose in that room. The skill reads the IDEA's verbs to decide, and asks only when the verbs genuinely don't settle it.

Everything downstream follows from those two: shot budget scaled to duration, cut times that leave each shot enough seconds to read, a dialogue word-budget so speech actually fits the runtime, camera moves drawn only from the model's motion-type enum, and dialogue preserved byte-for-byte in its original language inside `<d>[Language] …</d>`.

## Contents

| File | Role |
| --- | --- |
| `SKILL.md` | The 8-step workflow, mode-routing table, and pre-write validation checklist. Loaded whenever the skill triggers. |
| `references/output-formats.md` | Verbatim skeletons for all five modes — instruction lines, field order, spacing. Copied character-for-character. |
| `references/vision-extraction.md` | The per-image observation protocol, locked-detail lists, the FL2VA delta table, and L2VA reverse inference. |
| `references/craft-rules.md` | Camera motion enum, shot and cut timing, speaker IDs and `<d>` syntax, on-screen text, the two audio fields, density targets. |
| `references/full-reference-mode.md` | Label types, task-type prefixes, retention markers, and the six-section structure. |
| `references/examples.md` | Three worked runs — T2VA, I2VA with a vision pass, and a three-asset full-reference build. |

## Installation

**Claude Code** — clone into your skills directory:

```bash
git clone https://github.com/MushroomFleet/minimaxh3-enh-skill.git ~/.claude/skills/minimaxh3-enh
```

Or drop the folder into a project at `.claude/skills/minimaxh3-enh/` to scope it to that repo.

**Claude.ai / Cowork** — package it and upload the resulting `.skill` file in Settings → Capabilities → Skills:

```bash
zip -r minimaxh3-enh.skill minimaxh3-enh/
```

The skill has no dependencies and runs no code. It is instructions and reference material only.

## How to use it

Give Claude an IDEA and attach any reference images. The skill triggers on its own; naming it works too.

```text
minimaxH3-ENH: she blows out the candle
[attach: birthday-table.jpg]
```

```text
enhance this into a Hailuo prompt — my dog in my parents' living room,
someone off-screen calls his name and he bolts toward the camera,
use my voice from the clip
[attach: dog.jpg, livingroom.jpg, voice-memo.m4a]
```

```text
first and last frame prompt, 8 seconds, single shot:
she opens the umbrella in the rain
[attach: frame-start.png, frame-end.png]
```

You get back one markdown file — `[slug]-minimaxH3-prompt.md` — containing the complete prompt in a single fenced block, an image-slot map telling you which file is `Picture 1`, and short notes on the judgement calls made. Copy the block whole into MiniMax, attach the images in the mapped order, generate.

## Mode routing

| Situation | Mode | Main field |
| --- | --- | --- |
| No images, no reference video or audio | `T2VA` | `integrated_multimodal_description` |
| One image that is literally the opening frame | `I2VA` | `integrated_multimodal_description` |
| Two images that are literally the opening and closing frames | `FL2VA` | `integrated_multimodal_description` |
| One image that is literally the closing frame | `L2VA` | `integrated_multimodal_description` |
| Any image used as an identity / set / style donor | full-reference | `detailed_description` |
| Three or more assets, or any reference video or audio | full-reference | `detailed_description` |

## Defaults

Chosen deliberately, all overridable by saying so in the IDEA.

| Parameter | Default | Notes |
| --- | --- | --- |
| Duration | `6.00` seconds | Always formatted to two decimals; `10.00` when the action plainly needs it |
| Shot budget | 6s → 1–2 shots, 8s → 1–3, 10s → 2–4 | Each shot needs ~1.5s to register; FL2VA prefers a single shot |
| Dialogue budget | ~12–15 English words per 6s | ≈2.5–3 words/sec English, ≈4–5 characters/sec Mandarin |
| Description length | 110–220 words base modes, 350–500 full-reference | Scales with shot count and dialogue load; never padded |
| Interaction | Autonomous | Asks only on genuine mode ambiguity, impossible duration, or unclear dialogue language |
| Output | Markdown artifact | Say "inline" for a bare prompt block instead |

## Requirements

Claude Code, Claude.ai, or Cowork, with a vision-capable model — image reading is not optional to this skill's function. No packages, no runtime, no network access.

## License

See `LICENSE`. *(Not yet chosen — pick one and drop it in the repo root.)*

## 📚 Citation

### Academic Citation

If you use this codebase in your research or project, please cite:

```bibtex
@software{minimaxh3_enh,
  title = {minimaxH3-ENH: a Claude Skill for enhancing IDEAs into spec-compliant MiniMax Hailuo 3 video prompts},
  author = {Drift Johnson},
  year = {2026},
  url = {https://github.com/MushroomFleet/minimaxh3-enh-skill},
  version = {1.0.0}
}
```

### Donate:

[![Ko-Fi](https://cdn.ko-fi.com/cdn/kofi3.png?v=3)](https://ko-fi.com/driftjohnson)
